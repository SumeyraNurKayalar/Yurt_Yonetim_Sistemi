package com.yurt.design.builder;

import com.yurt.model.Room;

public interface RoomBuilder {
    void setRoomNumber(String roomNumber);
    void setCapacity(int capacity);

    Room build();
}