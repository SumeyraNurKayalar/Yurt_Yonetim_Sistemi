package com.yurt.design.builder;

import com.yurt.model.Room;

public class RoomDirector {

    private final RoomBuilder roomBuilder;

    public RoomDirector(RoomBuilder roomBuilder) {
        this.roomBuilder = roomBuilder;
    }

    // Mevcut metodunuz (Örn: 4 kişilik oda konfigürasyonu)
    public Room constructStandardRoom(String roomNumber, int capacity) {
        roomBuilder.setRoomNumber(roomNumber);
        roomBuilder.setCapacity(capacity);

        return roomBuilder.build();
    }

    // 🎯 EKLENECEK KISIM: constructSmallRoom metodu (Varsayım: 1 Kişilik Oda)
    public Room constructSmallRoom(String roomNumber) {
        // Builder'ı çağırarak 1 kişilik küçük oda konfigürasyonunu ayarlar
        roomBuilder.setRoomNumber(roomNumber);
        roomBuilder.setCapacity(1); // Küçük oda varsayımı

        return roomBuilder.build();
    }
}