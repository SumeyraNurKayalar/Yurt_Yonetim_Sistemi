package com.yurt.design.builder;

import com.yurt.model.Room;

public class StandardRoomBuilder implements RoomBuilder {

    private String roomNumber;
    private int capacity;

    @Override
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public Room build() {
        if (roomNumber == null || roomNumber.isEmpty() || capacity <= 0) {
            throw new IllegalStateException("Oda numarası ve geçerli kapasite zorunludur.");
        }

        // 🎯 Oda oluşturma işlemi (Room constructor'ı State'i otomatik başlatır)
        return new Room(this.roomNumber, this.capacity);
    }
}