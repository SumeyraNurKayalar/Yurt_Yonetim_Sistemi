package com.yurt.design.state;

import com.yurt.model.Room;

public class AvailableState implements IRoomState {
    private final Room room;

    public AvailableState(Room room) {
        this.room = room;
    }

    @Override
    public void handlePlacement() {
        if (room.getCurrentOccupancy() < room.getCapacity()) {

            room.setCurrentOccupancy(room.getCurrentOccupancy() + 1);
            System.out.println("LOG: Odaya bir kişi yerleştirildi. Yeni doluluk: " + room.getCurrentOccupancy());

            // Kapasite dolduysa durumu değiştir
            if (room.getCurrentOccupancy() == room.getCapacity()) {
                room.setState(new FullState(room));
                System.out.println("LOG: Oda doldu. Durum: FULL.");
            }
        }
    }

    @Override
    public void handleVacate() {
        if (room.getCurrentOccupancy() > 0) {
            room.setCurrentOccupancy(room.getCurrentOccupancy() - 1);
            System.out.println("LOG: Odadan bir kişi ayrıldı. Yeni doluluk: " + room.getCurrentOccupancy());
            // Zaten AvailableState'te kalır (Doluluk > 0 olduğu sürece)
        }
    }
}