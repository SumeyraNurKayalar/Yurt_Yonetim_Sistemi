package com.yurt.design.state;

import com.yurt.model.Room;

public class FullState implements IRoomState {
    private final Room room;

    public FullState(Room room) {
        this.room = room;
    }

    @Override
    public void handlePlacement() {
        // GEREKSİNİM: Kapasite dolu ise uyarı verir
        System.err.println("UYARI: Oda " + room.getRoomNumber() + " DOLU. Yerleştirme İPTAL edildi.");
    }

    @Override
    public void handleVacate() {
        room.setCurrentOccupancy(room.getCurrentOccupancy() - 1);
        System.out.println("LOG: Odadan bir kişi ayrıldı.");

        // Doluluk azaldığı için durum AvailableState'e geçer
        room.setState(new AvailableState(room));
    }
}