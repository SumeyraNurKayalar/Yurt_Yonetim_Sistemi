package com.yurt.design.state;

// Sadece oda doluluğu ile ilgilenir, Student nesnesine gerek duymaz
public interface IRoomState {
    void handlePlacement(); // Doluluk artırma işlemi
    void handleVacate();    // Doluluk azaltma işlemi
    // ... Diğer durum metotları (handleMaintenance vb.)
}