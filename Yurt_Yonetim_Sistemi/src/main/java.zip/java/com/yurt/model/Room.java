package com.yurt.model;

import com.yurt.design.state.IRoomState;
import com.yurt.design.state.AvailableState;

public class Room {
    private String roomId;
    private String roomNumber;
    private int capacity;
    private int currentOccupancy;
    private IRoomState currentState;

    public Room(String roomNumber, int capacity) {
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.currentOccupancy = 0;
        this.roomId = "R-" + roomNumber;
        // Başlangıç State ataması
        this.currentState = new AvailableState(this);
    }

    // State Deseni Metotları
    public void setState(IRoomState newState) {
        this.currentState = newState;
    }

    // Odaya bir kişi ekleme işlemini State nesnesine delege eder.
    public void addOccupant() {
        currentState.handlePlacement();
    }

    // Getters ve Setters
    public String getRoomId() { return roomId; }
    public String getRoomNumber() { return roomNumber; }
    public int getCapacity() { return capacity; }
    public int getCurrentOccupancy() { return currentOccupancy; }
    public void setCurrentOccupancy(int currentOccupancy) { this.currentOccupancy = currentOccupancy; }
    public IRoomState getCurrentState() { return currentState; }

    @Override
    public String toString() {
        String stateName = (currentState != null) ? currentState.getClass().getSimpleName() : "NOT_INITIALIZED";
        return "Room {roomNumber=" + roomNumber +
                ", capacity=" + capacity +
                ", occupancy=" + currentOccupancy +
                ", state=" + stateName + "}";
    }
}