package com.yurt.repository;

import com.yurt.model.Room;
import java.util.List;

public interface RoomRepository {
    Room save(Room room);
    Room findByRoomNumber(String roomNumber);
    List<Room> findAll();
    void update(Room room);

    // Doluluk bilgisini oda numarasına göre hesaplama
    int countOccupantsByRoomNumber(String roomNumber);

    // EK: Öğrencinin Odaya Yerleştiği Kaydı Oluşturma (Dolaylı Odalar tablosu işlemi)
    void recordStudentPlacement(int studentId, String roomNumber);
}