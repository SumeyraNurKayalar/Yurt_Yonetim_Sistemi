package com.yurt.repository.jdbc;

import com.yurt.model.Room;
import com.yurt.repository.RoomRepository;
import org.example.DatabaseConnection; // 🎯 DatabaseConnection sınıfını kullanıyoruz
import java.sql.*;
import java.util.*;

public class JdbcRoomRepository implements RoomRepository {

    // ----------------------------------------------------------------------------------
    // 🎯 Oda Oluşturma - save(Room)
    // Kaynak: Odalar Tablosu
    // ----------------------------------------------------------------------------------
    @Override
    public Room save(Room room) {
        // Yeni bir odanın DB'ye eklenmesi
        String sql = "INSERT INTO Odalar (oda_numarasi, kapasite) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection(); // Bağlantıyı çeker
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, room.getRoomNumber());
            pstmt.setInt(2, room.getCapacity());
            pstmt.executeUpdate();

            // Eğer odanın ID'sini Java modeline geri almak istersek:
            // try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) { ... }

            System.out.println("DB LOG: Oda " + room.getRoomNumber() + " başarıyla kaydedildi.");
            return room;

        } catch (SQLException e) {
            System.err.println("DB HATA (SAVE): Oda kaydedilemedi: " + e.getMessage());
            return null;
        } finally {
            // Bağlantı kapatma işlemini DatabaseConnection sınıfı yönetiyor.
        }
    }

    // ----------------------------------------------------------------------------------
    // 🎯 Oda Bilgisi Çekme - findByRoomNumber
    // Kaynak: Odalar Tablosu
    // ----------------------------------------------------------------------------------
    @Override
    public Room findByRoomNumber(String roomNumber) {
        String sql = "SELECT oda_id, oda_numarasi, kapasite FROM Odalar WHERE oda_numarasi = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, roomNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // DB verileriyle Room nesnesi oluşturulur (Builder değil, DB verisi)
                    int capacity = rs.getInt("kapasite");
                    String odaId = rs.getString("oda_id"); // Modeldeki roomId'ye atanır

                    // Room nesnesi oluşturulur
                    Room room = new Room(roomNumber, capacity);
                    // Doluluk bilgisini DB'den çekerek RoomState'i kurar
                    int occupancy = countOccupantsByRoomNumber(roomNumber);
                    room.setCurrentOccupancy(occupancy);

                    if (occupancy == capacity) {
                        // Eğer doluysa FullState'e geç
                        // room.setState(new FullState(room)); // State deseni logic'i
                    }

                    return room;
                }
            }
        } catch (SQLException e) {
            System.err.println("DB HATA (FIND): Oda bulunamadı: " + e.getMessage());
        }
        return null;
    }

    // ----------------------------------------------------------------------------------
    // 🎯 Odanın Mevcut Doluluğunu Hesaplama - countOccupantsByRoomNumber
    // Kaynak: Ogrenci_odaları Tablosu
    // ----------------------------------------------------------------------------------
    @Override
    public int countOccupantsByRoomNumber(String roomNumber) {
        // Sorgu: İlgili odada hala ikamet eden (bitis_tarihi NULL olan) öğrenci sayısını bul.
        String sql = "SELECT COUNT(oa.ogrenci_id) FROM Ogrenci_odaları oa " +
                "JOIN Odalar o ON oa.oda_id = o.oda_id " +
                "WHERE o.oda_numarasi = ? AND oa.bitis_tarihi IS NULL";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, roomNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("DB HATA (COUNT): Doluluk hesaplanamadı: " + e.getMessage());
        }
        return 0;
    }

    // ----------------------------------------------------------------------------------
    // 🎯 Odanın Durumunu/Kapasitesini Güncelleme - update(Room)
    // Kaynak: Odalar Tablosu
    // ----------------------------------------------------------------------------------
    @Override
    public void update(Room room) {
        // Odalar tablosunda kapasiteyi veya diğer statik bilgileri günceller.
        // Doluluk (currentOccupancy) bu tabloda tutulmadığı için güncellenemez.
        String sql = "UPDATE Odalar SET kapasite = ? WHERE oda_numarasi = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, room.getCapacity());
            pstmt.setString(2, room.getRoomNumber());
            pstmt.executeUpdate();
            System.out.println("DB LOG: Oda " + room.getRoomNumber() + " kapasitesi güncellendi.");

        } catch (SQLException e) {
            System.err.println("DB HATA (UPDATE): " + e.getMessage());
        }
    }

    // ----------------------------------------------------------------------------------
    // 🎯 Öğrenci Yerleştirme Kaydını Oluşturma - recordStudentPlacement
    // Kaynak: Ogrenci_odaları Tablosu
    // ----------------------------------------------------------------------------------
    @Override
    public void recordStudentPlacement(int studentId, String roomNumber) {
        String sql = "INSERT INTO Ogrenci_odaları (ogrenci_id, oda_id, baslangic_tarihi) " +
                "SELECT ?, oda_id, GETDATE() FROM Odalar WHERE oda_numarasi = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setString(2, roomNumber);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("DB LOG: Öğrenci yerleştirme kaydı Ogrenci_odaları tablosuna eklendi.");
            } else {
                System.err.println("DB HATA: Yerleştirme kaydı oluşturulamadı (Oda bulunamadı?).");
            }

        } catch (SQLException e) {
            System.err.println("DB HATA (PLACE): Öğrenci yerleştirme kaydı oluşturulamadı: " + e.getMessage());
        }
    }

    // findAll metodu benzer şekilde Odalar tablosundan tüm odaları çekmelidir...
    @Override
    public List<Room> findAll() {
        // ... implementation (Tüm odaları çekip her biri için doluluğu hesaplamalı)
        return Collections.emptyList(); // Şimdilik boş döndürüldü
    }
}