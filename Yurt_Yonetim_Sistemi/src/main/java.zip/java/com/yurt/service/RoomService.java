package com.yurt.service;

import com.yurt.model.Room;
import com.yurt.design.builder.RoomDirector;
import com.yurt.design.builder.StandardRoomBuilder;
import com.yurt.repository.RoomRepository;
import java.util.List;

// RoomController'dan gelecek çağrıları yöneten ana iş mantığı katmanı
public class RoomService {

    private final RoomRepository roomRepository;
    private final RoomDirector roomDirector;

    // Constructor ile Repository bağımlılığı verilir
    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
        this.roomDirector = new RoomDirector(new StandardRoomBuilder());
    }

    // Fonksiyon: Oda oluşturma
    public Room createRoom(String roomNumber, int capacity) {
        // BUILDER: Nesne oluşturulur
        Room newRoom = roomDirector.constructStandardRoom(roomNumber, capacity);

        // REPOSITORY: Veritabanına kaydet
        System.out.println("LOG: Oda " + roomNumber + " oluşturuldu ve kaydediliyor.");
        return roomRepository.save(newRoom);
    }

    // Fonksiyon: Odaya öğrenci yerleştirme (Doluluk artırma)
    public void addOccupantToRoom(String roomNumber) {
        Room room = roomRepository.findByRoomNumber(roomNumber);

        if (room != null) {
            // STATE: Durum davranışını tetikle
            room.addOccupant();

            // Güncel durumu ve doluluğu kaydet
            roomRepository.update(room);
        } else {
            System.err.println("HATA: Yerleştirme için gerekli oda bulunamadı.");
        }
    }

    // Fonksiyon: Tüm odaları listeleme
    public List<Room> listAllRooms() {
        System.out.println("LOG: Tüm odalar listeleniyor.");
        return roomRepository.findAll();
    }

    // Fonksiyon: Oda doluluk oranları (Opsiyonel)
    public double getOccupancyRate(String roomNumber) {
        Room room = roomRepository.findByRoomNumber(roomNumber);
        if (room != null && room.getCapacity() > 0) {
            // Oda doluluk oranını hesapla
            return (double) room.getCurrentOccupancy() / room.getCapacity() * 100;
        }
        return 0.0;
    }

    // Fonksiyon: Bir odadaki öğrencileri listeleme (Sadece Room nesnesi çekilebilir)
    public Room getRoomDetails(String roomNumber) {
        return roomRepository.findByRoomNumber(roomNumber);
    }
}