package org.example;

import com.yurt.design.builder.RoomBuilder;
import com.yurt.design.builder.RoomDirector;
import com.yurt.design.builder.StandardRoomBuilder;
import com.yurt.model.Room;

public class Main {
    public static void main(String[] args) {

        // 1. Somut Builder'ı seç (Şimdilik StandardRoomBuilder)
        RoomBuilder builder = new StandardRoomBuilder();

        // 2. Director'ı seçilen Builder ile başlat
        RoomDirector director = new RoomDirector(builder);

        // 3. Director'a bir oda inşa etme komutu ver
        // Personel, 4 kişilik 205 numaralı odayı oluşturuyor.
        Room room205 = director.constructStandardRoom("205", 4);
        System.out.println(room205);
        // Çıktı: Room {roomNumber = 205, capacity = 4, currentOccupancy = 0, state = AvailableState}

        // 4. Farklı bir oda oluşturma komutu
        // Personel, 1 kişilik 101 numaralı odayı oluşturuyor.
        Room room101 = director.constructSmallRoom("101");
        System.out.println(room101);
        // Çıktı: Room {roomNumber = 101, capacity = 1, currentOccupancy = 0, state = AvailableState}
    }
}